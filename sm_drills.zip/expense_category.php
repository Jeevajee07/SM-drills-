<?php 
include 'include/config.php';

// Add or Edit Expense Category
if (isset($_POST['add']) && $_POST['add'] == 'Create') {
    $expense_name = $_POST['expense_name'];
    $created_date = $_POST['created_date'];
    $expense_id = $_POST['expense_id'];

    if($expense_id == '') {
        // Add new expense category
        $query = "INSERT INTO `expense_category`(`expense_name`, `created_date`) VALUES ('$expense_name', '$created_date')";
    } else {
        // Update existing expense category
        $query = "UPDATE `expense_category` SET `expense_name`='$expense_name', `created_date`='$created_date' WHERE `expense_id`='$expense_id'";
    }
    
    mysqli_query($connect, $query) or die(mysqli_error($connect));

    echo "<script type='text/javascript'>window.location = 'expense_category.php?added=true'</script>";
}

// Fetch expense category for editing
$expense_name = '';
$created_date = '';
$expense_id = '';
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $query = "SELECT * FROM `expense_category` WHERE `expense_id`=$id";
    $result = mysqli_query($connect, $query) or die(mysqli_error($connect));
    $expense_category = mysqli_fetch_assoc($result);

    $expense_name = $expense_category['expense_name'];
    $created_date = $expense_category['created_date'];
    $expense_id = $expense_category['expense_id'];
}
?>
<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">
<head>
    <meta charset="utf-8" />
    <title>Add/Edit Expense Category</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />
    <script src="assets/js/layout.js"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'menu.php'; ?>
        <div class="vertical-overlay"></div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex align-items-lg-center flex-lg-row flex-column"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-header d-flex align-items-center">
                                                <h5 class="card-title mb-0 flex-grow-1">Add Expense Category</h5>
                                            </div>
                                            <div class="card-body">
                                                <form action="" method="post">
                                                    <div class="live-preview">
                                                        <div class="row gy-4">
                                                            <div class="col-xxl-3 col-md-4">
                                                                <div>
                                                                    <label for="expense_name" class="form-label">Expense Name</label>
                                                                    <input type="text" name="expense_name" id="expense_name" class="form-control" value="<?php echo $expense_name; ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="col-xxl-3 col-md-4">
                                                                <div>
                                                                    <label for="created_date" class="form-label">Created Date</label>
                                                                    <input type="date" name="created_date" id="created_date" class="form-control" value="<?php echo $created_date; ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="col-xxl-3 col-md-4">
                                                                <br>
                                                                <input type="hidden" name="expense_id" value="<?php echo $expense_id; ?>">
                                                                <button type="submit" name="add" value="Create" href="expense_category_list.php" class="btn btn-success btn-animation waves-effect waves-light">Submit</button>
                                                            </div>
                                                             <div class="card-header d-flex align-items-center justify-content-between">
   
                                                            <a href="expense_category_list.php" class="btn btn-primary">View Expense List</a>
                                                             </div>

                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
