<?php include 'include/config.php'; ?>
<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">
<head>
    <meta charset="utf-8" />
    <title>Purchase List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- jsvectormap css -->
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <style>
        .form-control {
            width: 250px; /* Adjust width as needed */
        }
        .btn {
            width: 120px; /* Adjust width as needed */
            height: 50px; /* Adjust height as needed */
        }
        .date-header {
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <!-- ========== App Menu ========== -->
        <?php include 'menu.php'; ?>
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content" style="background-color:white;">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex flex-column align-items-center" style="background-color: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                                            <div class="w-100 mb-3">
                                                <h5>Purchase Report</h5>
                                            </div>
                                            <div class="d-flex align-items-lg-center flex-lg-row flex-column w-100">
                                                <!-- Form for Date Range and Customer Name -->
                                                <form method="GET" action="" class="d-flex align-items-center mb-4 w-100">
                                                    <div class="form-group me-3">
                                                        <label for="from_date">From Date:</label>
                                                        <input type="date" id="from_date" name="from_date" class="form-control" style="width: 250px; height: 40px" value="<?php echo isset($_GET['from_date']) ? $_GET['from_date'] : ''; ?>" required>
                                                    </div>
                                                    <div class="form-group me-3">
                                                        <label for="to_date">To Date:</label>
                                                        <input type="date" id="to_date" name="to_date" class="form-control" style="width: 250px; height: 40px" value="<?php echo isset($_GET['to_date']) ? $_GET['to_date'] : ''; ?>" required>
                                                    </div>
                                                    <div class="form-group me-3">
                                                        <label for="customer_name">Customer Name:</label>
                                                        <select id="customer_name" name="customer_name" class="form-control" style="width: 250px; height: 40px" required>
                                                            <option value="">Select Customer</option>
                                                            <?php
                                                            // Fetch distinct customer names from the database
                                                            $query = "SELECT DISTINCT customer_name FROM invoice ORDER BY customer_name ASC";
                                                            $result = mysqli_query($connect, $query);
                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                $selected = (isset($_GET['customer_name']) && $_GET['customer_name'] == $row['customer_name']) ? 'selected' : '';
                                                                echo "<option value='" . $row['customer_name'] . "' $selected>" . $row['customer_name'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-primary mt-4" style="width: 150px; height: 40px">OK</button>
                                                    </div>
                                                    <div class="form-group ms-3">
                                                        <button type="reset" class="btn btn-danger mt-4" style="width: 150px; height: 40px" onclick="window.location.href=window.location.pathname">Clear</button>
                                                    </div>
                                                </form>
                                                <!-- End of Form -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php
                                if (isset($_GET['from_date']) && isset($_GET['to_date']) && isset($_GET['customer_name'])) {
                                    $from_date = $_GET['from_date'];
                                    $to_date = $_GET['to_date'];
                                    $customer_name = $_GET['customer_name'];

                                    $current_date = strtotime($from_date);
                                    $end_date = strtotime($to_date);
                                    
                                    while ($current_date <= $end_date) {
                                        $formatted_date = date("Y-m-d", $current_date);

                                    


                                        // Fetch data for the current date and customer name
                                        $query = "SELECT * FROM invoice WHERE inv_date = '$formatted_date' AND customer_name = '$customer_name' ORDER BY inv_id ASC;";
                                        $get_purchase = mysqli_query($connect, $query) or die(mysqli_error($connect));

                                        if (mysqli_num_rows($get_purchase) > 0) {
                                            echo "<b>Customer Name: </b>" .($customer_name)  ."<br>";
                                            echo "<b>DATE : </b>" . date("d-m-Y", $current_date) ;
                                            
                                            
                                            echo "<div class='card'>
                                                <div class='card-body'>
                                                    <table class='table table-bordered dt-responsive nowrap table-striped align-middle' style='width:100%'>
                                                        <thead>
                                                            <tr>
                                                                <th>S no</th>
                                                                <th>Date</th>
                                                                <th>Customer Name</th>
                                                                <th>Mobile Number</th>
                                                                <th>Total Amount</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>";

                                            $sno = 0;
                                            while ($fetch_purchase = mysqli_fetch_array($get_purchase)) {
                                                $sno++;
                                                $purchase_id = $fetch_purchase['inv_id'];
                                                $invoice_date = $fetch_purchase['inv_date'];
                                                $customer_name = $fetch_purchase['customer_name'];
                                                $mobile_no = $fetch_purchase['mobile_no'];
                                                $grand_total = $fetch_purchase['grand_total'];

                                                echo "<tr>
                                                        <td>{$sno}</td>
                                                        <td>{$invoice_date}</td>
                                                        <td>{$customer_name}</td>
                                                        <td>{$mobile_no}</td>
                                                        <td>" . number_format($grand_total, 2) . "</td>
                                                        <td>
                                                            <a href='invoice_print.php?purchase_id={$purchase_id}' class='btn btn-info btn-sm btn-icon waves-effect waves-light' target='_blank'><i class='bx bx-printer'></i></a>
                                                        </td>
                                                    </tr>";
                                            }
                                            echo "</tbody>
                                                </table>
                                            </div>
                                        </div>";
                                        }

                                        // Move to the next day
                                        $current_date = strtotime("+1 day", $current_date);
                                    }
                                }
                                ?>
                            </div> <!-- end .h-100-->
                        </div> <!-- end col -->
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <?php include 'footer.php'; ?>
        </div>
        <!-- end main content-->
    </div>
    <!-- END layout-wrapper-->

    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- apexcharts -->
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- Dashboard init -->
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
</body>
</html>
