<?php include 'include/config.php' ;?>
<!doctype html>

<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">



<head>

    <meta charset="utf-8" />
    <title>Machine Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- jsvectormap css -->
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />

</head>

<style>
    .button-container {
            display: flex;
        }
</style>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?php include 'header.php'; ?>

        <!-- ========== App Menu ========== -->
            <?php include 'menu.php'; ?>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
              
                    <?php
                    
                    
                    
                    if(isset($_GET['action']) =='' || $_GET['action'] == 'list') {

?>

                    <div class="row">
                        <div class="col">

                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex align-items-lg-center flex-lg-row flex-column">
                                            <!-- <div class="flex-grow-1">
                                                <h4 class="fs-16 mb-1">Good Morning, Anna!</h4>
                                               
                                            </div> -->
</div>

                                            <?php
                                            $mac_id = $_GET['mac_id'];
                                            $machine_name = $_GET['machine_name'];
                                            ?>

                                            <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                            <div class="card-header d-flex align-items-center">
                                <?php
                                 $get_mac = mysqli_query($connect,"SELECT * FROM `machine_list` where mac_id = '$mac_id' ") or die(mysqli_error($connect));
                  while($fetch_aspayment = mysqli_fetch_array($get_mac))
            {
                $mac_id = $fetch_aspayment['mac_id'];

                $machine_name = $fetch_aspayment['machine_name'];
        
        
       
        ?>
                                    <h5 class="card-title mb-0 flex-grow-1">Daily Entries - <?php echo $machine_name; ?></h5>
                                    
                                    <?php
            }
            ?>
                                    <div>
                                        <a href="add_machine_details.php?mac_id=<?php echo $mac_id; ?>&machine_name=<?php echo $machine_name; ?>">
                                        <button id="addRow" class="btn btn-primary">Add details</button>
</a>
                                    </div>
                                </div>
                                <div class="card-body" style="overflow: auto;">
                                    
                                    
                                    <?php
                                     if(isset($_POST['search']))
                                        {
                                          $from_date =$_POST['from_date'];
                                          $to_date =$_POST['to_date'];
                                        }
                                        ?>
                                    
                                     <table width="100%">
        <form name="form" action="#" method="post">
                   
                      <div class="form-group">
                           
                      <div class="col-sm-12 button-container">
                          <div class="col-sm-1" >From date : </div>
                <?php
                if(isset($_POST['search']))
                 {
                ?>
                            
                            <input type="date"  class="form-control" name="from_date" id="from_date" value="<?php echo date('Y-m-d',strtotime($from_date)); ?>">
                <?php
                }else{
                ?>
                            <input type="date"  class="form-control" name="from_date" id="from_date" value="<?php echo date('Y-m-d'); ?>">
                <?php
                }
                ?>
                
                 <div class="col-sm-1" style="margin-left:20px;">To date : </div>
                <?php
                if(isset($_POST['search']))
                 {
                ?>
                            
                            <input type="date"  class="form-control" name="to_date" id="to_date" value="<?php echo date('Y-m-d',strtotime($to_date)); ?>">
                <?php
                }else{
                ?>
                            <input type="date"  class="form-control" name="to_date" id="to_date" value="<?php echo date('Y-m-d'); ?>">
                <?php
                }
                ?>
                
                
                 <div class="" style="margin-left:2%;">
                <a class="form-control btn btn-warning" href="machine_details_print.php?mac_id=<?php echo $mac_id; ?>&machine_name=<?php echo $machine_name; ?>&from_date=<?php echo $from_date;?>&to_date=<?php echo $to_date;?>" target="_blank">Print</a>
                </div>
               <div class="col-sm-1" style="margin-left:2%;">
                <button class="form-control btn btn-primary" type="submit" name="search">OK</button>
                </div>
                <div class="col-sm-1 text-center" style="margin-left:10px; ">
                <a href="machine_details.php" class="form-control btn btn-danger ">CLEAR</a>
                </div>
            </div>
        
          
                      
                     </div>
                     </div>
                 </form>
                 </table>
                                   
                                    <br><br>






<?php


        
       


            


$today = date("Y-m-d");
    if(isset($_POST['search']))
        {
              $from_date =$_POST['from_date'];
                                          $to_date =$_POST['to_date'];
?>


<?php

//  $from_dates = '$from_date';
// $from_date = '2023-06-01'; // Example start date
// $to_date = '2023-06-05';   // Example end date

// Convert the dates to timestamps
 $from_dates = strtotime($from_date);
$to_date = strtotime($to_date);



// Loop through each day between the start and end dates
for ($date = $from_dates; $date <= $to_date; $date = strtotime("+1 day", $date)) {

     
       
    $hi2 =  date("Y-m-d", $date);
    
    
         $mac_details =  mysqli_query($connect,"SELECT * FROM `machine_details` where `mac_id` = '$mac_id' and mdate = '$hi2' ORDER BY `mac_id` DESC ") or die(mysqli_error());
            $countmac_details = mysqli_num_rows($mac_details);
            if($countmac_details != '')
            {
    
     echo "<b>DATE : </b>". $hi =  date("d-m-Y", $date);
    ?>


                                    
                                    <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:max-content">
                                       <thead>
                                            <tr>
                                               
                                            <th>S no</th>
                                            <th>Date</th>
                                            <th>Shift</th>
                                            <th>Operator Name</th>
                                            <th>Bench No</th>
                                            <th>Material</th>
                                           
                                            
                                            <th>SRPM</th>
                                            <th>CRPM</th>
                                            <th>HRS</th>
                                            <th>No.Of.Holes(1)</th>
                                            <th>No.Of.Holes(2)</th>
                                            <th>No.Of.Holes(3)</th>
                                            <th>No.Of.Holes(4)</th>
                                            <th>Holes Depth (1)</th>
                                            <th>Holes Depth (2)</th>
                                            <th>Holes Depth (3)</th>
                                            <th>Holes Depth (4)</th>
                                            <th>Total MTR</th>
                                            <th>Average</th>
                                            <th>HSD</th>
                                            <th>RPM</th>
                                            <th>HRS</th>
                                            <th>Average</th>
                                            <th>SRPM</th>
                                            <th>CPRM</th>
                                            <th>T HRS</th>
                                            <th>HSD</th>
                                            <th>RPM</th>
                                            <th>HRS</th>
                                            <th>Average</th>
                                            
                                                
                                            </tr>
                                           
                                            </thead>
                                               
                                           
                                        
                                        <tbody>
                                         <?php
                                          if(isset($_POST['search']))
                                        {

                                                $sno =0;
                                                
                                                
                                                
                                                
                                        //   echo "SELECT * FROM `machine_details` where `mac_id` = '2' and date = '$hi2' ORDER BY `date` DESC ";
                               
                                                $get_machine = mysqli_query($connect,"SELECT * FROM `machine_details` where `mac_id` = '$mac_id' and mdate = '$hi2' ORDER BY `mac_id` DESC ") or die(mysqli_error());
                                                
                                            
                                        }else{
                                                     $get_machine = mysqli_query($connect,"SELECT * FROM `machine_details` where `mac_id` = '$mac_id' and mdate = '$today' ORDER BY `mac_id` DESC ") or die(mysqli_error());
                                                    
                                            
                                        }
                                                while($fetch_machine = mysqli_fetch_array($get_machine))

                                                {

                                                $sno++;
                                                
                                                $mac_id   =$fetch_machine['mac_id'];

                                                $mdate   =$fetch_machine['mdate'];
                                                $shift   =$fetch_machine['shift'];
                                                $operator_name   =$fetch_machine['operator_name'];
                                                $bench_no   =$fetch_machine['bench_no'];
                                                $material   =$fetch_machine['material'];
                                                $srpm1   =$fetch_machine['srpm1'];
                                                $crpm   =$fetch_machine['crpm'];
                                                $hrs1   =$fetch_machine['hrs1'];
                                                $no_of_holes1   =$fetch_machine['no_of_holes1'];
                                                $no_of_holes2   =$fetch_machine['no_of_holes2'];
                                                $no_of_holes3   =$fetch_machine['no_of_holes3'];
                                                $no_of_holes4   =$fetch_machine['no_of_holes4'];
                                                $holes_depth1   =$fetch_machine['holes_depth1'];
                                                $holes_depth2   =$fetch_machine['holes_depth2'];
                                                $holes_depth3   =$fetch_machine['holes_depth3'];
                                                $holes_depth4   =$fetch_machine['holes_depth4'];
                                                $total_mtr   =$fetch_machine['total_mtr'];
                                                $average1   =$fetch_machine['average1'];
                                                $hsd1   =$fetch_machine['hsd1'];
                                                $rpm1   =$fetch_machine['rpm1'];
                                                $hrs2   =$fetch_machine['hrs2'];
                                                $average2   =$fetch_machine['average2'];
                                                $srpm2   =$fetch_machine['srpm2'];
                                                $cprm   =$fetch_machine['cprm'];
                                                $t_hrs   =$fetch_machine['t_hrs'];
                                                $hsd2   =$fetch_machine['hsd2'];
                                                $rpm2   =$fetch_machine['rpm2'];
                                                $hrs3   =$fetch_machine['hrs3'];
                                                $average3   =$fetch_machine['average3'];


                                                ?>
                                            <tr>
                                                                                    

              
                                               
                                                <td><?php echo $sno  ;?></td>
                                                <td><?php echo $mdate  ;?></td>
                                                <td><?php echo $shift  ;?></td>
                                                <td><?php echo $operator_name  ;?></td>
                                                <td><?php echo $bench_no  ;?></td>
                                                <td><?php echo $material  ;?></td>
                                                
                                                <td><?php echo $srpm1 ;?></td>
                                                <td><?php echo $cprm ;?></td>
                                                <td><?php echo $hrs1 ;?></td>
                                                <td><?php echo $no_of_holes1 ;?></td>
                                                <td><?php echo $no_of_holes2 ;?></td>
                                                <td><?php echo $no_of_holes3 ;?></td>
                                                <td><?php echo $no_of_holes4 ;?></td>
                                                <td><?php echo $holes_depth1 ;?></td>
                                                <td><?php echo $holes_depth2 ;?></td>
                                                <td><?php echo $holes_depth3 ;?></td>
                                                <td><?php echo $holes_depth4 ;?></td>
                                                <td><?php echo $total_mtr ;?></td>
                                                <td><?php echo $average1 ;?></td>
                                                <td><?php echo $hsd1 ;?></td>
                                                <td><?php echo $rpm1 ;?></td>
                                                <td><?php echo $hrs2 ;?></td>
                                                <td><?php echo $average2 ;?></td>
                                                <td><?php echo $srpm2 ;?></td>
                                                <td><?php echo $cprm ;?></td>
                                                <td><?php echo $t_hrs ;?></td>
                                                <td><?php echo $hsd2 ;?></td>
                                                <td><?php echo $rpm2 ;?></td>
                                                <td><?php echo $hrs3 ;?></td>
                                                <td><?php echo $average3 ;?></td>
                                                
                                            </tr>
                                            <?php
                                            $counttotalmtr += $total_mtr;
                                            $counthrs1 += $hrs1;
                                            $counthsd1 += $hsd1;
                                            $counthsd2 += $hsd2;
                                            $countthrs += $t_hrs;
                                            
                                            
                                                }
                                                ?>
                                               
                                           
                                        </tbody>
                                    </table>
<?php 
}
           }
    
   
        ?>
        
        <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:50%">
                                       <thead>
                                            <tr>
                                                <th>S no</th>
                                                <th>Description</th>
                                                <th>Value</th>
                                                <th>Unit</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            <td>1</td>
                                            <td>Machine Total Meters</td>
                                            <td><?php echo $counttotalmtr; ?></td>
                                            <td>Meters</td>
                                            </tr>
                                            <tr>
                                            <td>2</td>
                                            <td>Total Diesel Consumed</td>
                                            <td><?php echo $counthsd1 + $counthsd2; ?></td>
                                            <td>Litres</td>
                                            </tr>
                                            <tr>
                                            <td>3</td>
                                            <td>Diesel Avg </td>
                                            <td><?php echo ($counthsd1 + $counthsd2)/$counttotalmtr; ?></td>
                                            <td>L/M</td>
                                            </tr>
                                            <tr>
                                            <td>4</td>
                                            <td>Hitachi Running Hrs</td>
                                            <td><?php echo $countthrs ; ?></td>
                                            <td>Hrs</td>
                                            </tr>
                                            <tr>
                                            <td>5</td>
                                            <td>Hitachi Diesel Consumption</td>
                                            <td><?php echo $counthsd2; ?></td>
                                            <td>Litres</td>
                                            </tr>
                                            <tr>
                                            <td>6</td>
                                            <td>Hitachi Diesel Avg</td>
                                            <td><?php echo $counthsd2 / $countthrs; ?></td>
                                            <td>L/Hr</td>
                                            </tr>
                                            <tr>
                                            <td>7</td>
                                            <td>Compressor Running Hrs</td>
                                            <td><?php echo $counthrs1; ?> </td>
                                            <td>Hrs</td>
                                            </tr>
                                            <tr>
                                            <td>8</td>
                                            <td>Compressor Diesel Consumed</td>
                                            <td><?php echo $counthsd1; ?></td>
                                            <td>Litres</td>
                                            </tr>
                                            <tr>
                                            <td>9</td>
                                            <td>Compressor Diesel Avg</td>
                                            <td><?php echo $counthsd1/$counthrs1; ?></td>
                                            <td>L/Hr</td>
                                            </tr>
                                            <tr>
                                            <td>10</td>
                                            <td>Compressor Output/Hour</td>
                                            <td><?php echo $counttotalmtr/$counthrs1; ?></td>
                                            <td>Meter/Hour</td>
                                            </tr>
                                            <tr>
                                            <td>11</td>
                                            <td>Average Operator wise</td>
                                            
                                            <td colspan='2'>To be calculated </td>
                                            </tr>
                                        </tbody>
                                        </table>
                                               
                                           
                                </div>
       
                            </div>
                        </div><!--end col-->
                    </div><!--end row-->
 </div><!-- end card-body -->


                                        </div><!-- end card header -->
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->


                            
       <?php
       }}
       ?>
                        </div> <!-- end col -->

                    </div>

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

           <?php include 'footer.php'; ?>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->



    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- apexcharts -->
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

    <!-- Vector map-->
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- Dashboard init -->
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>

    <!-- App js -->
    <script src="assets/js/app.js"></script>
</body>

</html>