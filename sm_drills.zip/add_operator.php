<?php include 'include/config.php' ;


if ($_POST['add'] == 'Create')
{
 $operator_name = $_POST['operator_name'];
$operator_contact = $_POST['operator_contact'];

mysqli_query($connect,"INSERT INTO `operator`(`operator_name`, `operator_contact`) 
VALUES ('$operator_name','$operator_contact')")or die(mysqli_error($connect));


echo "<script type='text/javascript'>window.location = 'operator_list.php'</script>";

}

?>
<!doctype html>

<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">



<head>

    <meta charset="utf-8" />
    <title>Add Operator</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- jsvectormap css -->
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />

</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?php include 'header.php'; ?>

        <!-- ========== App Menu ========== -->
            <?php include 'menu.php'; ?>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col">

                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex align-items-lg-center flex-lg-row flex-column">
                                            <!-- <div class="flex-grow-1">
                                                <h4 class="fs-16 mb-1">Good Morning, Anna!</h4>
                                               
                                            </div> -->
</div>


                                <!-- Start from -->

                                <div class="row">
                        <div class="col-lg-12 " >
                            <div class="card ">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Add Operator</h4>
                                    <div class="flex-shrink-0">
                                        
                                    </div>
                                </div><!-- end card header -->
                                <div class="card-body">
                                    <div class="live-preview">
                                        <div class="row gy-4">
                                            <div class="col-xxl-3 col-md-4">
                                            <form action=""  method="post">
                                                <div>
                                                    <label for="" class="form-label">Operator Name</label><br>
                                                    <input type="text" name="operator_name" id="operator_name" class="form-control" id="basiInput">
                                                </div>
                                                </div>
                                            <!--end col-->
                                                
                                            <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label for="" class="form-label">Operator Contact</label>
                                                    <input type="text" name="operator_contact" id="operator_contact" class="form-control" id="basiInput">
                                                </div>
                                            </div>
                                            
                                            <!--end col-->
                                           
                                           
                                            <div class="d-grid gap-2 col-3 mx-auto">
                                                                        <br>
                                            <button type="submit" name="add" value="Create" class="btn btn-success btn-animation waves-effect waves-light" >Submit</button>
</div>
                                            
                                            <!--end col-->
                                           
                                            <!--end col-->
                                        </div>
                                        <!--end row-->
                                    </div>
</form>
                                    
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                                           
                    </div><!--end row-->



                                        </div><!-- end card header -->
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->


                            </div> <!-- end .h-100-->

                        </div> <!-- end col -->

                    </div>

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

           <?php include 'footer.php'; ?>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->



    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- apexcharts -->
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

    <!-- Vector map-->
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- Dashboard init -->
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>

    <!-- App js -->
    <script src="assets/js/app.js"></script>
</body>



</html>