<?php
include 'include/config.php';
?>

<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">

<head>
    <meta charset="utf-8" />
    <title>Customers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Customer Management" name="description" />
    <meta content="Themesbrand" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
</head>

<body>

    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'menu.php'; ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h5 class="card-title mb-0">Customers</h5>
                                            <a href="add_customer.php">
                                                <button id="addRow" class="btn btn-primary ml-auto">Add Customer</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Name</th>
                                                            <th>Email</th>
                                                            <th>Phone</th>
                                                            <th>Address</th>
                                                            <th>GST No</th>
                                                            <th>Feedback</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        
                                                        $sno = 0;
                                                        
                                                        $get_customers = mysqli_query($connect, "SELECT * FROM customers ORDER BY name ASC");
                                                        while ($customer = mysqli_fetch_array($get_customers)) {
                                                            $sno++;
                                                            
                                                            
                                                            echo "<tr>
                                                                <td>{$sno}</td>
                                                                <td>{$customer['name']}</td>
                                                                <td>{$customer['email']}</td>
                                                                <td>{$customer['phone']}</td>
                                                                <td>{$customer['address']}</td>
                                                                <td>{$customer['gst_no']}</td>
                                                                <td>{$customer['feedback']}</td>
                                                                <td>
                                                                    <a href='delete_customer.php?id={$customer['id']}' class='btn btn-danger btn-icon waves-effect waves-light'><i class='ri-delete-bin-5-line'></i></a>
                                                                    <a href='edit_customer.php?id={$customer['id']}' class='btn btn-warning btn-icon waves-effect waves-light'><i class='ri-pencil-fill'></i></a>
                                                                </td>
                                                            </tr>";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div><!-- end col-->
                                </div><!-- end row-->

                            </div> <!-- end .h-100-->
                        </div> <!-- end col -->
                    </div>
                </div>
            </div>

            <?php include 'footer.php'; ?>
        </div>
    </div>

    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
    <script src="assets/js/app.js"></script>
</body>

</html>
