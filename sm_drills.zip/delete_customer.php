<?php
include 'include/config.php';

if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];
    
    // Perform deletion query
    $delete_query = "DELETE FROM customers WHERE id = $customer_id";
    $result = mysqli_query($connect, $delete_query);

    if ($result) {
        echo "Customer deleted successfully.";
        // Redirect back to customer list or any other page
        header("Location: customers.php");
        exit();
    } else {
        echo "Error deleting customer: " . mysqli_error($connect);
    }
} else {
    echo "Customer ID not specified.";
}
?>
