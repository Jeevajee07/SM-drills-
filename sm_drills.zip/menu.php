 <div class="app-menu navbar-menu">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <!-- Dark Logo-->
                <a href="index.html" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="assets/images/logo-sm.png" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="assets/images/logo-dark.png" alt="" height="17">
                    </span>
                </a>
                <!-- Light Logo-->
                <a href="index.html" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="assets/images/logo-sm.png" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="assets/images/logo-light.png" alt="" height="17">
                    </span>
                </a>
                <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
                    <i class="ri-record-circle-line"></i>
                </button>
            </div>
    
           
                <div class="container-fluid">


                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="dashboard.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Dashboards</span>
                            </a>
                          
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="site.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class="ri-building-4-fill"></i> <span data-key="t-dashboards">Site</span>
                            </a>
                          
                        </li>
                        
                        
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="machine_list.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" las la-box"></i> <span data-key="t-dashboards">Machine</span>
                            </a>
                          
                        </li>
                    
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="operator_list.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" ri-user-settings-fill"></i><span data-key="t-dashboards">Operator</span>
                            </a>
                          
                        </li>
                        
                         <li class="nav-item">
                            <a class="nav-link menu-link" href="product_list.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" ri-product-hunt-fill"></i><span data-key="t-dashboards">Product</span>
                            </a>
                          
                        </li>
                        
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="purchasenew.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class="  ri-product-hunt-line"></i><span data-key="t-dashboards">Purchase Order</span>
                            </a>
                          
                        </li>
                        
                        
                        
                        
                        
                        
                         <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarLayouts" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarLayouts">
                                <i class="ri-store-3-fill"></i> <span data-key="t-layouts">Inventory</span> 
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarLayouts">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="stock_in.php"  class="nav-link" data-key="t-horizontal">Stock-In</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="stock_out.php" class="nav-link" data-key="t-detached">Stock-Out</a>
                                    </li>
                                   
                                </ul>
                            </div>
                        </li>
                        
                        
                        
                       <li class="nav-item">
                            <a class="nav-link menu-link" href="add_expenses.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" ri-wallet-3-fill"></i><span data-key="t-dashboards">Daily Expenses</span>
                            </a>
                          
                        </li>



                        <li class="nav-item">
                            <a class="nav-link menu-link" href="expense_category.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" ri-wallet-3-fill"></i><span data-key="t-dashboards"> Expenses category</span>
                            </a>
                          
                        </li>
                        

                        
                        
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="customers.php" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">
                                <i class=" ri-account-circle-line"></i> <span data-key="t-dashboards">Customer</span>
                            </a>
                          
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarLayouts" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarLayouts">
                                <i class="ri-store-3-fill"></i> <span data-key="t-layouts">Reports</span> 
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarLayouts">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="machine_details.php?mac_id=2&machine_name=crusher%2045"  class="nav-link" data-key="t-horizontal">Machine Report</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="purchase_list.php" class="nav-link" data-key="t-detached">Purchase Order Report</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="expense_list.php" class="nav-link" data-key="t-detached">Expense Report</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="stock_in_list.php" class="nav-link" data-key="t-detached">Stock-In Report</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="stock_out_list.php" class="nav-link" data-key="t-detached">Stock-Out Report</a>
                                    </li>
                                   
                                </ul>
                            </div>
                        </li>

                
                        
                        
                        
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link menu-link" href="" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">-->
                        <!--        <i class=" ri-line-chart-line"></i> <span data-key="t-dashboards">Sales</span>-->
                        <!--    </a>-->
                          
                        <!--</li>-->
                        
                             
                        
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link menu-link" href="" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">-->
                        <!--        <i class="    ri-list-check"></i> <span data-key="t-dashboards">List</span>-->
                        <!--    </a>-->
                          
                        <!--</li>-->
                        
                        
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link menu-link" href="" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">-->
                        <!--        <i class="  las la-truck"></i> <span data-key="t-dashboards">Diesel Rate</span>-->
                        <!--    </a>-->
                          
                        <!--</li>-->
                        
                        
                        
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link menu-link" href="" data-bs-toggle="" role="button" aria-expanded="false" aria-controls="sidebarDashboards">-->
                        <!--        <i class="  ri-user-add-line"></i> <span data-key="t-dashboards">Ledger Account</span>-->
                        <!--    </a>-->
                          
                        <!--</li>-->
                        
                       
                        
                     

                         <!-- end Dashboard Menu -->
                       

                    </ul>
                </div>
                <!-- Sidebar -->

            <div class="sidebar-background"></div>
        </div>