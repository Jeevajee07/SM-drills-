<?php include 'include/config.php' ;
?>




<!doctype html>

<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">



<head>

    <meta charset="utf-8" />
    <title>Purchase</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- jsvectormap css -->
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    
    <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>



<style>
 .panel{
     margin:40px;
     border:1px solid black;
 }

</style>



<!--<script type="text/javascript">-->

<!--window.print();-->

<!--</script>-->




<section class="panel">
<header class="panel-heading">
<div class="panel-add" style="float:right;">
<a  href="javascript:void(0);" onclick="javascript:window.print();" >
    <button class="btn btn-sm btn-success" style="width:100px; border-radius:20px;"><i class="fa fa-print"></i>Print</button>
     </a>
</div>

<h2 class="panel-title" style="font-weight:600; font-size:18px;">Purchase Order
</h2>
</header>
<div class="panel-body">
<div class="cardInvice ">
<!-- BEGIN INVOICE HEADER -->
<div class="row" id="inv-header" style="border:1px solid gray; border-radius:10px;">
<div class="col-xs-8 text-right">

</div>
<!--<div class="col-xs-4 text-right">-->
<!--<h6 class="bold"><b>GSTIN : 33CXFPN1926C1ZU</b></h6>-->
<!--</div>-->
<div class="col-xs-2 pad10" style="margin-top: -30px;">
<!--<h2 class="Inv-logo text-danger"  style="width: 80%;margin-top: 1px; margin-left:30px; font-weight:bolder; font-size:30px;">Sm Drills</h2>-->
</div>
<div class="col-xs-7 text-center" style="margin-top: -33px;">
<!-- <h4 class="bold" style="font-size: 12px">Credit Bill</h4> -->
<!--<h4 class="bold" style="font-size: 12px">TAX INVOICE</h4>-->
<h2 class="text-info text-uppercase margin5 jai mt-5"><span class="text-accent-dark" style="font-size:18px; font-weight:600;">Sm Drilling & MINING SERVICES</span></h2>
<!--  <h5 class="bold" id="Dealers"> </h5> -->
<h5 class="bold in-address" style="font-weight:580;">Appachi Gounder Thottam, Sankari R.S. – 637 302. Salem Dt. Tamilnadu</h5>
 <h5 style="font-weight:580;">Email:smdrillingcompany@gmail.com</h5>
</div>



<div class="col-xs-3 " style="margin-top: -55px;">
<!-- <div class="clearfix text-right">
<div class="pull-left">
<i class="fa fa-phone fa-2x" style="margin-left: 10px"></i>
</div>
<div class="pull-right">
<p class="text-right invoice-mobile"></p>
</div>
</div> -->
<div class="clearfix text-right">
<div class="pull-left">
<i class="fa fa-mobile fa-2x" style="margin-left: 12px"></i>
</div>
<div class="pull-right">
<p class="text-right invoice-mobile" style="font-size:14px; text-align:right; font-weight:580; margin-right:10px;">+91 6374247413</p>

<!-- <p class="text-right invoice-mobile">0000 - 0000</p>  -->
</div>
</div>
</div>
</div><!--end .row -->

<!-- END INVOICE HEADER -->
<!-- <div class="row padtop5" id="inv-header-tamil">
<div class="col-xs-12">
<h4 class="bold" style='font-family: Latha, "Tamil MN", serif; font-size: 160%;'> சேலம்-9 </h4>
</div>
</div> -->



            <?php
            
            $inv_id1 = $_GET['purchase_id'];
?>



  <?php

      
            // echo "SELECT * FROM `invoice` where inv_id='$inv_id1' ORDER BY inv_id ASC; ";
        $get_purchase = mysqli_query($connect,"SELECT * FROM `invoice` where inv_id='$inv_id1' ORDER BY inv_id ASC; ") or die(mysqli_error());

        while($fetch_purchase = mysqli_fetch_array($get_purchase))

        {

        $sno++;
        
        $invoice_no = $fetch_purchase['inv_no'];

        $invoice_date = $fetch_purchase['inv_date'];
        $customer_name = $fetch_purchase['customer_name'];
        $mobile_no = $fetch_purchase['mobile_no'];
        $address = $fetch_purchase['address'];
        $grand_total = $fetch_purchase['grand_total'];
        $igst = $fetch_purchase['igst'];
       
        }
        ?>




<!-- BEGIN INVOICE DESCRIPTION -->
<div class="row padtop5" style="display:inline;">
<!--end .col -->
<div class="mt-2 " id="inv-to" style="border:1px solid gray; border-radius:10px; width:900px; ">
   
   <div class="mt-2" style="float:right; font-weight:580; margin-right:10px;  font-size:12px;">
    <h6>Invoice No : <span><?php echo $invoice_no; ?></span></h6>
    <h6>Invoice Date : <span><?php echo $invoice_date; ?> </span></h6>
    </div> 
<div class="mx-3">
<h5 class="bold mt-2" style="font-weight:580;">To :</h5>
<address id="to-address" style="font-weight:580;  font-size:12px;">
<strong>
<?php echo $address; ?><br>
<abbr>Phone no : <?php echo $mobile_no; ?></abbr> 
<p style="font-weight:bolder;  font-size:12px;"> GST NO :</abbr> 08BEJPH0209C1Z3</p>
</address>
</div>

</div><!--end .col -->


<div class="container mx-5 mt-2 mb-2">
  <div class="row">
    <div class="col-lg-4" style="font-weight:bold; font-size:10px;">
      Terms of Delivary: At the earliest
    </div>
      <div class="col-lg-4">
      
    </div>
    <div class="col-lg-4"  style="font-weight:bold; font-size:10px;">
      Validity: 15 days from date of purchase order

    </div>
    
    <div style="font-weight:bold; font-size:10px;">
       Instruction: Please mention our PO. NO, in all correspondence, challan, invoice etc.

    </div>
    
  </div>
</div>


</div><!--end .row -->
<!-- END INVOICE DESCRIPTION -->
<!-- <br> -->
<!-- BEGIN INVOICE PRODUCTS -->
<div class="row" style="margin-top: 5px">
<div class="col-md-12" style="padding: 0;">
<form action="" method="post">
<table class="table table-bordered" style="    font-size: 12px;">

<!-- <table class="table table-bordered" style="    font-size: 10.5px;"> -->
<thead>
<tr>
<th style="width:10px" class="text-left">Sno</th>

<th style="width:350px" class="text-left">Particulars</th>
<th style="width:50px" class="text-left">Unit</th>
<th style="width:50px" class="text-left">Qty</th>
<th style="width:100px" class="text-left">Rate</th>
<th style="width:110px" class="text-left">Amount</th>
</tr>
</thead>
<tbody>
    
    
    
    <?php
    
    $total_amount2 = mysqli_query($connect,"SELECT sum(total_amount) AS addtotal_amount FROM invoiceadd  where purchase_id = '$inv_id1' ") or die(mysqli_error($connect));

while ($fetch_tran = mysqli_fetch_array($total_amount2))
{
    $total_amount3 = $fetch_tran['addtotal_amount'];
}
    
    ?>
    
    
    
    <?php
    
            $sno =0;
        $get_invoice = mysqli_query($connect,"SELECT * FROM `invoiceadd` where purchase_id = '$inv_id1' ORDER BY invoiceadd_id ASC; ") or die(mysqli_error());

        while($fetch_invoice = mysqli_fetch_array($get_invoice))

        {

        $sno++;
        
        $purchase_id = $fetch_invoice['purchase_id'];
         $invoice_date = $fetch_invoice['invoice_date'];
          $product_name = $fetch_invoice['product_name'];
           $unit = $fetch_invoice['unit'];
            $quantity = $fetch_invoice['quantity'];
             $price = $fetch_invoice['price'];
             $total_amount = $fetch_invoice['total_amount'];
             $gst = $fetch_invoice['gst'];

                
                $grand_total = $total_amount3 + $igst;
                
    
    ?>
    
    
    

<tr>
<td><?php echo $sno; ?></td>
<td><?php echo $product_name; ?></td>
<td><?php echo $unit; ?></td>
<td><?php echo $quantity; ?></td>
<td><?php echo number_format($price,2); ?></td>
<td><?php echo number_format($total_amount,2); ?></td>
</tr>
    
        <?php
        }
        ?>

<tr>
<td colspan="5" class="text-right"><strong style="font-size: 10.5px; text-align:right;">Total</strong></td>
<td class="text-left"><?php echo number_format($total_amount3,2); ?></td>
</tr>

<tr>
<td colspan="5" class="text-right"><strong style="font-size: 10.5px; text-align:right;">GST</strong></td>
<td class="text-left"><?php echo number_format($gst,2); ?> %</td>
</tr>

<tr>
<td colspan="5" class="text-right"><strong style="font-size: 10.5px; text-align:right;">IGST</strong></td>
<td class="text-left"><?php echo number_format($igst,2); ?></td>
</tr>


<tr>
<td colspan="5" class="text-right"><strong style="font-size: 14px; text-align:right; font-weight:bold;">Grand Total</strong></td>
<td class="text-left" style="font-weight:bold; font-size: 14px;"><?php echo number_format($grand_total,2); ?></td>
</tr>



    <tr>
        <td colspan="6" class="text-right" style="text-align:right;"></td>
    
        </tr>
        
         <tr>
        <td colspan="2" class="text-right" style="font-size:10px; font-weight:bold;" >REJECTION:</td>
        <td colspan="4" class="text-left" style="font-size:10px; font-weight:600; text-align:center;">FOR SM DRILLING & MINING SERVICES</td>
        </tr>
        
        
         <tr>
        <td colspan="2" class="text-right" style="font-size:10px; font-weight:bold;">If the material supplied is rejected, you should replace the material<br>
                                            immediately as per this order, you have to lift the material from site<br>
</td>
        
        </tr>
        
        
         <tr>
        <td colspan="2" class="text-right" ></td>
        <td colspan="4" class="text-left" style="font-size:10px; font-weight:600; text-align:center;">AUTHORISED SIGNATORY</td>
        </tr>
        
        
    
        
        
        </tbody>
            </table>
            
            
            
            
            </form></div><!--end .col -->
            </div><!--end .row -->
            <br>
            <!--<div class="row">-->
                <!--end .col -->
                
            <!--    <div class="purchasered" id="purchaser_sign">-->
            <!--        <p class="bold" style="margin-top: 5px;font-size: 10px;">Purchaser Signature</p>-->
            <!--        </div><!--end .col -->
            <!--        <div class="termed" id="terms">-->
            <!--            <div class="" style="float: left;position: relative;width: 7%">-->
            <!--                <h5 style="font-size: 10px" class="bold">Terms:</h5>-->
            <!--            </div>-->
            <!--            <div class="" style="float: left;position: relative;width: 93%;margin-left: -8px;margin-top: 0px;">-->
                            
            <!--                <ol style="font-size: 10px" class="bold">-->
            <!--                    <li>Goods once sold will not be taken back or exchanged.</li>-->
                                
            <!--                    <li>Subject to Salem Jurisdiction.</li>-->
            <!--                </ol>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--        <div class="authorised">-->
            <!--            <div id="authorised-sign" style="font-size: 10px">-->
            <!--                <span>For <strong>Vetrivel Traders</strong></span>-->
            <!--                <p class="bold" style="margin-top: 2px;font-size: 10px;">Authorised Signature</p>-->
            <!--            </div>-->
            <!--            </div><!--end .col -->
            <!--        </div>-->
                    <!-- END INVOICE PRODUCTS -->
                    </div><!--end .card-body -->
                    
                </div>
            </section>
            
            
            </body>
            </html>