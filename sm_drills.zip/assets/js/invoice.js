 <script>
                      
                      function sum(...numbers) {
            return numbers.reduce((acc, curr) => acc + curr, 0);
        }
                      
                      
                      
                    function myFunction() 
                            {
                              var price = document.getElementById("price").value;
                              var quantity = document.getElementById("quantity").value;
                              var igst = document.getElementById("igst").value;
                              var total_price = document.getElementById("total1").innerHTML;
                              var total_price1 = Number(total_price);
                              var total = parseFloat(price) * quantity;
                              
                              var grand_total = parseFloat(total_price)*(igst/100);
                              
                              var grand_total_1 = sum(grand_total, total_price1);
                              
                            //   alert(typeof(grand_total));
                              
                             
                              
                            //   alert(grand_total);
                            
                             document.getElementById("grand_total").innerHTML =  grand_total_1;
                              
                              
                              if (!isNaN(total))
                                document.getElementById("total_amount1").innerHTML = total;
                                
                             
                            }
                            
                            
                            //  if (!isNaN(total))
                            //     document.getElementById("total_amount1").innerHTML = total;
                                
                             
                            // }
                            
                </script>