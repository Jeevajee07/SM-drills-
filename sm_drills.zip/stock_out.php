<?php
include 'include/config.php';

if (isset($_POST['remove']) && $_POST['remove'] == 'Remove') {
    $product_name = $_POST['product_name'];
    $product_quantity = $_POST['product_quantity'];
    $product_description = $_POST['product_description'];
    $stockout_date = $_POST['sdate'];

    // Check if the product exists in the `stock_in` table
    $stockin = mysqli_query($connect, "SELECT * FROM `stock_in` WHERE product_name='$product_name'") or die(mysqli_error($connect));
    $fetch_stockin = mysqli_fetch_array($stockin);
    $sproduct_name = $fetch_stockin['product_name'];
    $sproduct_quantity = $fetch_stockin['product_quantity'];

    // Validate product name and quantity
    if ($sproduct_name == $product_name) {
        if ($sproduct_quantity >= $product_quantity) {
            $total_qty = $sproduct_quantity - $product_quantity;

            // Update the stock quantity in `stock_in`
            mysqli_query($connect, "UPDATE `stock_in` SET `product_quantity`='$total_qty' WHERE product_name='$sproduct_name'") or die(mysqli_error($connect));

            // Insert a record into `stock_out` table
            mysqli_query($connect, "INSERT INTO `stock_out` (product_id, product_name, product_quantity, product_description, stockout_date)
                                    VALUES ('$sproduct_name', '$product_name', '$product_quantity', '$product_description', '$stockout_date')") or die(mysqli_error($connect));

            // Redirect to product list page after successful operation
            echo "<script type='text/javascript'>window.location = 'product_list.php'</script>";
            exit;
        } else {
            // Notify if there is insufficient stock
            echo "<script>alert('Insufficient stock to remove.'); window.location = 'stock_out_list.php';</script>";
            exit;
        }
    } else {
        // Notify if the product does not exist
        echo "<script>alert('Product does not exist.'); window.location = 'stock_out_list.php';</script>";
        exit;
    }
}
?>

<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">
<head>
    <meta charset="utf-8" />
    <title>Remove Stocks</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />
    <script src="assets/js/layout.js"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <style>
        .view-report-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'menu.php'; ?>
        <div class="vertical-overlay"></div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex align-items-lg-center flex-lg-row flex-column"></div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header align-items-center d-flex">
                                                        <h4 class="card-title mb-0 flex-grow-1">Remove Product</h4>
                                                        <a href="stock_out_list.php" class="btn btn-secondary view-report-btn">View Report</a>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="live-preview">
                                                            <div class="row gy-4">
                                                                <div class="col-xxl-3 col-md-2">
                                                                    <form action="" method="post">
                                                                        <div>
                                                                            <label for="sdate" class="form-label">Date</label><br>
                                                                            <input type="date" name="sdate" id="sdate" class="form-control" required>
                                                                        </div>
                                                                </div>
                                                                <div class="col-xxl-3 col-md-3">
                                                                    <label for="product_name" class="form-label">Product Name</label>
                                                                    <select name="product_name" id="product_name" class="selectpicker form-control" data-live-search="true" required>
                                                                        <option value="" disabled selected>Select a product</option>
                                                                        <?php
                                                                        $Get_Products = mysqli_query($connect,"SELECT * FROM stock_in ORDER BY product_name ASC") or die(mysqli_error($connect));
                                                                        while($Fetch = mysqli_fetch_array($Get_Products)) {
                                                                            $product_name = $Fetch['product_name'];
                                                                        ?>
                                                                        <option value="<?php echo $product_name; ?>"><?php echo $product_name; ?></option>
                                                                        <?php
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                <div class="col-xxl-3 col-md-3">
                                                                    <div>
                                                                        <label for="product_quantity" class="form-label">Product Quantity</label>
                                                                        <input type="number" name="product_quantity" id="product_quantity" class="form-control" required>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xxl-3 col-md-3">
                                                                    <div>
                                                                        <label for="product_description" class="form-label">Product Description</label>
                                                                        <textarea class="form-control" name="product_description" id="product_description" rows="1"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="d-grid gap-2 col-3 mx-auto">
                                                                    <button type="submit" name="remove" value="Remove" class="btn btn-danger btn-animation waves-effect waves-light">Submit</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
