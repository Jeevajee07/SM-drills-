<?php
error_reporting(0);

//---> Connect to DB --->
$DB_HOST = 'localhost';
$DB_USER = 'growtechnologies_smdrills';
$DB_PASS = 'smdrills@123';
$DB_NAME = 'growtechnologies_smdrills_db';
$connect = mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);

if (!$connect) {
    die('Connect Error : (' . mysqli_connect_errno() . ')<hr/>'. mysqli_connect_error());
}

function EncodeURL($url)
{
$new = strtolower(ereg_replace(' ','_',$url));
return($new);
}

function DecodeURL($url)
{
$new = ucwords(ereg_replace('_',' ',$url));
return($new);
}

/*************************************
			        Alert
*************************************/

function pageStatus($status_type)
{
  if($status_type == 'added')  {  
  echo '<div class="alert alert-success"><button data-dismiss="alert" class="close"></button><strong>Record created succesfully</strong>   </div>'; 
  }
  else if($status_type == 'updated')  {
  echo '<div class="alert alert-success"><button data-dismiss="alert" class="close"></button><strong>Record Updated succesfully</strong></div>';
  } 
  else if($status_type == 'deleted')  {
  echo '<div class="alert alert-danger"><button data-dismiss="alert" class="close"></button><strong>Record removed succesfully</strong></div>';
  }
  else if($status_type == 'log_out')  {
    echo '<div class="alert alert-success"><button data-dismiss="alert" class="close"></button><strong>Logged out successfully.  Thankyou for using me:)</strong></div>';
  }else if($status_type == 'loggedIN')  {
    echo '<div class="alert alert-success"><button data-dismiss="alert" class="close"></button><strong>Welcome admin.  Check what you got today.</strong></div>';
  }
}

//page error
function errorStatus($edit_type)
{
  if(!empty($edit_type))  { 
  echo '<div class="alert alert-danger"><button data-dismiss="alert" class="close"></button><strong>';
  foreach ($edit_type as $e) { echo "$e <br>"; }  
  echo '</strong></div>';
  }
}





// ?>