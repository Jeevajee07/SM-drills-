<?php include 'include/config.php' ;


// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);



if ($_POST['submit'] == 'Save Invoice')
{
$invoice_no   =$_POST['invoice_no'];
$invoice_date   =$_POST['invoice_date'];
$customer_name   =$_POST['customer_name'];
$mobile_no   =$_POST['mobile_no'];
$address   =$_POST['address'];
$gst   =$_POST['gst'];
$igst   =$_POST['i_gst'];
$grand_total   =$_POST['grand_total'];


$current_date = date('Y-m-d');


  $Get_Cust1 = mysqli_query($connect,"SELECT * from invoice where inv_id ") or die(mysqli_error($connect));

          while($Fetch_cus = mysqli_fetch_array($Get_Cust1))

          {

          $customer_name1 = $Fetch_cus['customer_name'];

          $inv_id = $Fetch_cus['inv_id'];

}

// if($customer_name == $customer_name1 && $current_date == $invoice_date)
// {

//      mysqli_query($connect,"UPDATE `invoice` SET `inv_no`='$invoice_no',`inv_date`='$invoice_date',`customer_name`='$customer_name',`mobile_no`='$mobile_no',`address`='$address',`gst`='$gst',`igst`='$igst',`grand_total`='$grand_total' WHERE inv_id = '$inv_id' ") or die(mysqli_error($connect));
// }
// else{
    

$addcust = mysqli_query($connect,"INSERT INTO `invoice`(`inv_no`, `inv_date`, `customer_name`, `mobile_no`,`address`, `gst`, `igst`, `grand_total`) 
VALUES ('$invoice_no','$invoice_date','$customer_name','$mobile_no','$address','$gst','$igst','$grand_total')") or die(mysqli_error($connect));



  $Get_Cust1 = mysqli_query($connect,"SELECT * from invoice where inv_id ") or die(mysqli_error($connect));

          while($Fetch_cus = mysqli_fetch_array($Get_Cust1))

          {

          $customer_name1 = $Fetch_cus['customer_name'];

          $inv_id = $Fetch_cus['inv_id'];

}





            $rows = [];
            for ($i = 0; $i < count($_POST["product_name"]); $i++) {
                $product_name = mysqli_real_escape_string($connect, $_POST["product_name"][$i]);
                $unit = mysqli_real_escape_string($connect, $_POST["unit"][$i]);
                $price = mysqli_real_escape_string($connect, $_POST["price"][$i]);
                $quantity = mysqli_real_escape_string($connect, $_POST["quantity"][$i]);
                $total = mysqli_real_escape_string($connect, $_POST["total"][$i]);
                
                 $rows[] = "('$invoice_date', '$product_name', '$inv_id', '$unit', '$quantity', '$price', '$total', '$gst')";
            }
            
            if (!empty($rows)) {
                $query = "INSERT INTO `invoiceadd` (`invoice_date`, `product_name`, `purchase_id`, `unit`, `quantity`, `price`, `total_amount`, `gst`) VALUES ";
                
            
                
                $query .= implode(", ", $rows);
                
            if (mysqli_query($connect, $query)) {
        echo "New records created successfully";
    } else {
        echo "Error: " . mysqli_error($connect);
    }
}


            

// exit();





// $add_invoice = mysqli_query($connect,"INSERT INTO `invoiceadd`(`invoice_date`, `product_name`, `purchase_id`, `unit`, `quantity`, `price`, `total_amount`, `gst`) VALUES ") or die(mysqli_error($connect));

// $rows= [];
// for($i=0;$i<count($_POST["product_name"]);$i++)
//             {
//                 $product_name=$_POST["product_name"][$i];
//                 $unit=$_POST["unit"][$i];
//                 $price=$_POST["price"][$i];
//                 $quantity=$_POST["quantity"][$i];
//                 $total=$_POST["total"][$i];
                
//                  $rows[]="('$inv_id','$product_name','$unit','$price','$quantity','$total')";

//             }
//              $add_invoice.=implode(",",$rows);
            


// echo "<script type='text/javascript'>window.location = 'site.php'</script>";

}

?>
<!doctype html>

<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">



<head>

    <meta charset="utf-8" />
    <title>Purchase</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- jsvectormap css -->
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?php include 'header.php'; ?>

        <!-- ========== App Menu ========== -->
            <?php include 'menu.php'; ?>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col">

                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex align-items-lg-center flex-lg-row flex-column">
                                            <!-- <div class="flex-grow-1">
                                                <h4 class="fs-16 mb-1">Good Morning, Anna!</h4>
                                               
                                            </div> -->
</div>


                                <!-- Start from -->

                                <div class="row">
                        <div class="col-lg-12 " >
                            
                            <div class="card ">
                                <!--<div class="card-header align-items-center d-flex">-->
                                <!--    <h4 class="card-title mb-0 flex-grow-1">Add site</h4>-->
                                <!--    <div class="flex-shrink-0">-->
                                        
                                <!--    </div>-->
                                <!--</div>-->
                                <!-- end card header -->
                                <div class="card-body">
                                    <h5 class="text-success">Customer Details</h5><br>
                            <form action=""  method="post">
                                    <div class="live-preview">
                                        <div class="row gy-4">
                                            <div class="col-xxl-3 col-md-4">
                                                <?php
                                                
                                                  $Get_Cust1 = mysqli_query($connect,"SELECT * from invoice where inv_id ") or die(mysqli_error($connect));
                                                    
                                                              while($Fetch_cus = mysqli_fetch_array($Get_Cust1))
                                                    
                                                              {
                                                    
                                                              $customer_name1 = $Fetch_cus['customer_name'];
                                                    
                                                              $inv_id = $Fetch_cus['inv_id'];
                                                              
                                                              $inv_id++;
                                                    
                                                              }
                                                    ?>
                                            
                                                <div>
                                                    <label for="" class="form-label">Invoice No</label><br>
                                                    <input type="text" name="invoice_no" id="invoice_no" class="form-control" value="<?php echo "SM".$inv_id; ?> ">
                                                </div>
                                                </div>
                                                
                                               
                                            <!--end col-->
                                                
                                            <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label for="" class="form-label">Invoice Date</label>
                                                    <input type="date" name="invoice_date" id="invoice_date" class="form-control" >
                                                </div>
                                            </div>
                                            
                                            <!--end col-->
                                           
                                            <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label for="" class="form-label">Customer Name</label>
                                                    <input type="text" name="customer_name" id="customer_name" class="form-control" >
                                                </div>
                                            </div>
                                            
                                             <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label for="" class="form-label">Customer Number</label>
                                                    <input type="text" name="mobile_no" id="mobile_no" class="form-control" >
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="col-xxl-3 col-md-4">
                                                <div>
                                                    <label for="" class="form-label">Address</label>
                                                    <input type="text" name="address" id="address" class="form-control" >
                                                </div>
                                            </div>
                                            
                                            <!--end col-->
                                           
                                            <!--end col-->
                                        </div>
                                        
                                        <br>
                                        <hr>
                                        <br>
                                        
                                        
                                        <div class="row gy-4">
                                            
                                            
                                            
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h5 class="text-success">Product Details</h5><br>
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th>Product</th>
                                                                <th>Unit</th>
                                                                <th>Price</th>
                                                                <th>Quantity</th>
                                                                <th>Total</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="product_tbody">
                                                            <tr>
                                                                <td>
                                                                
                                                                
                                                        <select name="product_name[]" id="product_name"  class="selectpicker form-control" data-live-search="true" chosen onchange="get_account_details_sales(this.value)" onfocus="get_account_details_sales(this.value)">
                                                    
                                                            
                                                              
                                                    
                                                              <?php
                                                              
                                                              
                                                    
                                                              $Get_Cust = mysqli_query($connect,"SELECT * from product where product_id ORDER BY product_name ASC") or die(mysqli_error());
                                                    
                                                              while($Fetch = mysqli_fetch_array($Get_Cust))
                                                    
                                                              {
                                                    
                                                              $product_name = $Fetch['product_name'];
                                                    
                                                              $product_id = $Fetch['product_id'];
                                                    
                                                              ?>
                                                    
                                                              <option value="<?php echo $product_name; ?>" >
                                                    
                                                              <?php echo $product_name; ?>
                                                    
                                                              </option>
                                                    
                                                              <?php
                                                    
                                                              }
                                                    
                                                              ?>
                                                              
          
                                                             </select>
                                      
                                                             </td>                                                
                                                         
                                                                <td><input type="text" required name="unit[]" id="unit" class="form-control"></td>
                                                                <td><input type="text" required name="price[]" id="price" class="form-control price"></td>
                                                                <td><input type="text" required name="quantity[]" id="quantity" class="form-control quantity"></td>
                                                                <td><input type="text" required name="total[]" id="total" class="form-control total"></td>
                                                                <td><input type="button"  value="x" class="btn btn-danger btn-sm btn-row-remove" ></td>
                                                            </tr>
                                                            
                                                            <tr>
                                                                <td>
                                                                
                                                                
                                                        <select name="product_name[]" id="product_name"  class="selectpicker form-control" data-live-search="true" chosen onchange="get_account_details_sales(this.value)" onfocus="get_account_details_sales(this.value)">
                                                    
                                                            
                                                              
                                                    
                                                              <?php
                                                              
                                                              
                                                    
                                                              $Get_Cust = mysqli_query($connect,"SELECT * from product where product_id ORDER BY product_name ASC") or die(mysqli_error());
                                                    
                                                              while($Fetch = mysqli_fetch_array($Get_Cust))
                                                    
                                                              {
                                                    
                                                              $product_name = $Fetch['product_name'];
                                                    
                                                              $product_id = $Fetch['product_id'];
                                                    
                                                              ?>
                                                    
                                                              <option value="<?php echo $product_name; ?>" >
                                                    
                                                              <?php echo $product_name; ?>
                                                    
                                                              </option>
                                                    
                                                              <?php
                                                    
                                                              }
                                                    
                                                              ?>
                                                              
          
                                                             </select>
                                      
                                                             </td>                                                
                                                         
                                                                <td><input type="text" required name="unit[]" id="unit" class="form-control"></td>
                                                                <td><input type="text" required name="price[]" id="price" class="form-control price"></td>
                                                                <td><input type="text" required name="quantity[]" id="quantity" class="form-control quantity"></td>
                                                                <td><input type="text" required name="total[]" id="total" class="form-control total"></td>
                                                                <td><input type="button"  value="x" class="btn btn-danger btn-sm btn-row-remove" ></td>
                                                            </tr>
                                                            
                                                            
                                                            <tr>
                                                                <td>
                                                                
                                                                
                                                        <select name="product_name[]" id="product_name"  class="selectpicker form-control" data-live-search="true" chosen onchange="get_account_details_sales(this.value)" onfocus="get_account_details_sales(this.value)">
                                                    
                                                            
                                                              
                                                    
                                                              <?php
                                                              
                                                              
                                                    
                                                              $Get_Cust = mysqli_query($connect,"SELECT * from product where product_id ORDER BY product_name ASC") or die(mysqli_error());
                                                    
                                                              while($Fetch = mysqli_fetch_array($Get_Cust))
                                                    
                                                              {
                                                    
                                                              $product_name = $Fetch['product_name'];
                                                    
                                                              $product_id = $Fetch['product_id'];
                                                    
                                                              ?>
                                                    
                                                              <option value="<?php echo $product_name; ?>" >
                                                    
                                                              <?php echo $product_name; ?>
                                                    
                                                              </option>
                                                    
                                                              <?php
                                                    
                                                              }
                                                    
                                                              ?>
                                                              
          
                                                             </select>
                                      
                                                             </td>                                                
                                                         
                                                                <td><input type="text" required name="unit[]" id="unit" class="form-control"></td>
                                                                <td><input type="text" required name="price[]" id="price" class="form-control price"></td>
                                                                <td><input type="text" required name="quantity[]" id="quantity" class="form-control quantity"></td>
                                                                <td><input type="text" required name="total[]" id="total" class="form-control total"></td>
                                                                <td><input type="button"  value="x" class="btn btn-danger btn-sm btn-row-remove" ></td>
                                                            </tr>
                                                            
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                            
                                                                <td><input type="button"  value="+ Add Row" class="btn btn-info btn-sm" id="add_row"></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td>Total</td>
                                                                <td><input type="text" name="total_amount" id="total_amount" class="form-control"  readonly></td>
                                                            </tr>
                                                            <tr>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td>GST</td>
                                                                <td><input type="text" name="gst" id="gst" class="form-control gst" onkeyup="calculate()"></td>
                                                            </tr>
                                                            
                                                            <tr>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td>IGST</td>
                                                                <td><input type="text" name="i_gst" id="i_gst" class="form-control"  readonly></td>
                                                            </tr>
                                                            <tr>
                                                                <td></td>
                                                                <td></td>
                                                                <td></td>
                                                                <td>Grand Total</td>
                                                                <td><input type="text" name="grand_total" id="grand_total" class="form-control"  readonly></td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                    <input type='submit' name='submit' value='Save Invoice' class='btn btn-success float-right'>
                                                </div>
                                            </div>
                                            
                                            
                                            <!--<div class="d-grid gap-2 col-3 mx-auto">-->

                                            <!--<button type="submit" name="add" value="Create" class="btn btn-success btn-animation waves-effect waves-light" >Submit</button>-->
                                            <!--</div>-->
                                            
                                        </div>
                                        
                                        <!--end row-->
                                    </div>
                                </form>
                                
                                
                             
                                
                                <script>
                                    $(document).ready(function(){
                                        
                                        
                                        $("#add_row").click(function(){
                                 
                                 
                                           var row = `<tr><td><input type="text" required name="product_name[]" id="product_name" class="form-control"></td>
                                            
                                            <td><input type='text' required name='unit[]' id='unit' class='form-control'></td><td><input type='text' required name='price[]' id='price' class='form-control price'></td><td><input type='text' required name='quantity[]' id='quantity' class='form-control quantity'></td><td><input type='text' required name='total[]' id='total' class='form-control total'></td><td><input type='button'  value='x' class='btn btn-danger btn-sm btn-row-remove' ></td></tr>`;
                                            
                                            $("#product_tbody").append(row);
                                        });
                                        
                                       $("body").on("click",".btn-row-remove",function(){
                                          if(confirm("Are You Sure?")){
                                            $(this).closest("tr").remove();
                                            total_amount();
                                          }
                                        });
                                        
                                        
                                        $("body").on("keyup",".price",function(){
                                      var price=Number($(this).val());
                                      var quantity=Number($(this).closest("tr").find(".quantity").val());
                                      var total = Number($(this).closest("tr").find(".total").val(price*quantity));
                                      total_amount();
                                      
                                    //   alert(total);
                                    });
                                    
                                    $("body").on("keyup",".quantity",function(){
                                      var quantity=Number($(this).val());
                                      var price=Number($(this).closest("tr").find(".price").val());
                                      var total = Number($(this).closest("tr").find(".total").val(price*quantity));
                                      total_amount();
                                      
                                    //   alert(price);
                                      
                                    });
                                    
                                    
                                    //  $("body").on("keyup ", ".gst", function() {
                                    //     var gst = Number($(this).val());
                                    //     var total1 = Number($(this).closest("tr").find(".total").val());
                                    //     var gst_amount = Number(total1 * (gst / 100));
                                    //     var igst = Number($(this).closest("tr").find(".igst").val(gst_amount));
                                    //     total_amount();
                                        
                                    //     alert(gst_amount);
                                        
                                    // });
                                    
                                    
                                    
                                    
                                     function total_amount(){
                                      var tot=0;
                                      $(".total").each(function(){
                                        tot+=Number($(this).val());
                                      });
                                      $("#total_amount").val(tot);
                                    }
                                        
                                            
                                    });
                                    
                                    
                                    
                                    $('#gst').keyup(function(ev) {
                                    var gst = Number($("#gst").val());
                                    var total_amount = Number($("#total_amount").val());
                                    
                                    var tot_price = (total_amount * gst / 100);
                                    
                                    var total_amount1 = tot_price + total_amount;
                                    
                                    var g_total = document.getElementById('grand_total');
                                    var i_gst = document.getElementById('i_gst');
                                    g_total.value = total_amount1;
                                    i_gst.value = tot_price;
                                    
                                    // alert(tot_price);
                                  });
                                    
                                    
                                    
                                </script>
                                    
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                                           
                    </div><!--end row-->



                                        </div><!-- end card header -->
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->


                            </div> <!-- end .h-100-->

                        </div> <!-- end col -->

                    </div>

                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

           <?php include 'footer.php'; ?>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->



    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- apexcharts -->
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

    <!-- Vector map-->
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- Dashboard init -->
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>

    <!-- App js -->
    <script src="assets/js/app.js"></script>
</body>



</html>