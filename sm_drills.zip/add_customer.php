<?php
include 'include/config.php';

// Initialize variables
$id = $name = $email = $phone = $feedback = $address = $gst_no = '';
$errors = [];
$edit_mode = false;

// Check if ID parameter is set for editing
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $edit_mode = true;
    $id = $_GET['id'];

    // Fetch customer details from database based on $id
    $get_customer_query = "SELECT * FROM customers WHERE id = $id";
    $result = mysqli_query($connect, $get_customer_query);

    if ($result && mysqli_num_rows($result) > 0) {
        $customer = mysqli_fetch_assoc($result);
        $name = $customer['name'];
        $email = $customer['email'];
        $phone = $customer['phone'];
        $feedback = $customer['feedback'];
        $address = $customer['address'];
        $gst_no = $customer['gst_no'];
    } else {
        echo "Customer not found.";
        exit(); // Exit if customer not found
    }
}

// Handle form submission for both adding and editing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($connect, $_POST['name']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $feedback = mysqli_real_escape_string($connect, $_POST['feedback']);
    $address = mysqli_real_escape_string($connect, $_POST['address']);
    $gst_no = mysqli_real_escape_string($connect, $_POST['gst_no']);

    // Check for existing customer with the same email or phone
    $check_query = "SELECT * FROM customers WHERE (email = '$email' OR phone = '$phone')";
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = $_POST['id'];
        $check_query .= " AND id != $id"; // Exclude the current customer in case of update
    }
    $check_result = mysqli_query($connect, $check_query);

    if ($check_result && mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('A customer with the same email or phone number already exists.');</script>";
    } else {
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Update existing customer
            $id = $_POST['id'];
            $update_query = "UPDATE customers SET 
                             name = '$name', 
                             email = '$email', 
                             phone = '$phone', 
                             feedback = '$feedback', 
                             address = '$address', 
                             gst_no = '$gst_no' 
                             WHERE id = $id";

            $update_result = mysqli_query($connect, $update_query);

            if ($update_result) {
                echo "<script>alert('Customer updated successfully.');</script>";
                header("Location: customers.php");
                exit();
            } else {
                echo "<script>alert('Error updating customer: " . mysqli_error($connect) . "');</script>";
            }
        } else {
            // Add new customer
            $insert_query = "INSERT INTO customers (name, email, phone, feedback, address, gst_no) 
                             VALUES ('$name', '$email', '$phone', '$feedback', '$address', '$gst_no')";

            $insert_result = mysqli_query($connect, $insert_query);

            if ($insert_result) {
                echo "<script>alert('New customer added successfully.');</script>";
                header("Location: customers.php");
                exit();
            } else {
                echo "<script>alert('Error adding new customer: " . mysqli_error($connect) . "');</script>";
            }
        }
    }
}
?>

<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">

<head>
    <meta charset="utf-8" />
    <title><?php echo $edit_mode ? 'Edit Customer' : 'Add Customer'; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Customer Management" name="description" />
    <meta content="Themesbrand" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
</head>

<body>

    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'menu.php'; ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h5 class="card-title mb-0"><?php echo $edit_mode ? 'Edit Customer' : 'Add Customer'; ?></h5>
                                            <a href="customers.php">
                                                <button id="addRow" class="btn btn-primary ml-auto">View Customers</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                    <?php if ($edit_mode) : ?>
                                                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
                                                    <?php endif; ?>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="name" class="form-label">Name</label>
                                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="email" class="form-label">Email</label>
                                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="phone" class="form-label">Phone</label>
                                                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="address" class="form-label">Address</label>
                                                            <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($address); ?>">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="gst_no" class="form-label">GST No</label>
                                                            <input type="text" class="form-control" id="gst_no" name="gst_no" value="<?php echo htmlspecialchars($gst_no); ?>">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="feedback" class="form-label">Feedback</label>
                                                            <textarea class="form-control" id="feedback" name="feedback"><?php echo htmlspecialchars($feedback); ?></textarea>
                                                        </div>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary"><?php echo $edit_mode ? 'Update Customer' : 'Add Customer'; ?></button>
                                                </form>
                                            </div>
                                        </div>
                                    </div><!-- end col-->
                                </div><!-- end row-->

                            </div> <!-- end .h-100-->
                        </div> <!-- end col -->
                    </div>
                </div>
            </div>

            <?php include 'footer.php'; ?>
        </div>
    </div>

    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
    <script src="assets/js/app.js"></script>
</body>

</html>
