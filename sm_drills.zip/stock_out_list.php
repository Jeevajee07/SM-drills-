<?php include 'include/config.php'; ?>
<!doctype html>
<html lang="en" data-layout="horizontal" data-layout-style="" data-layout-position="fixed" data-topbar="light">
<head>
    <meta charset="utf-8" />
    <title>Stock Out List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link href="assets/libs/jsvectormap/css/jsvectormap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />
    <script src="assets/js/layout.js"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <style>
        .form-control {
            width: 250px;
        }
        .btn {
            width: 120px;
            height: 50px;
        }
        .date-header {
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div id="layout-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'menu.php'; ?>
        <div class="vertical-overlay"></div>
        <div class="main-content" style="background-color:white;">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <div class="h-100">
                                <div class="row mb-3 pb-1">
                                <div class="col-12">
    <div class="d-flex flex-column align-items-lg-center" style="background-color: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <div class="w-100 mb-3">
            <p class="mb-0"></p>
            <p><h5>Stock-Out Report</h5></p>
        </div>
        <form method="GET" action="" class="d-flex align-items-center mb-4 w-100">
            <div class="form-group me-3">
                <label for="from_date">From Date:</label>
                <input type="date" id="from_date" name="from_date" class="form-control" style="width: 350px; height: 40px" value="<?php echo isset($_GET['from_date']) ? $_GET['from_date'] : ''; ?>" required>
            </div>
            <div class="form-group me-3">
                <label for="to_date">To Date:</label>
                <input type="date" id="to_date" name="to_date" class="form-control" style="width: 350px; height: 40px" value="<?php echo isset($_GET['to_date']) ? $_GET['to_date'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary mt-4" style="width: 150px; height: 40px">OK</button>
            </div>
            <div class="form-group ms-3">
                <button type="reset" class="btn btn-danger mt-4" style="width: 150px; height: 40px; margin-left: 10px;" onclick="window.location.href=window.location.pathname">Clear</button>
            </div>
        </form>
    </div>
</div>

                                </div>

                                <?php
                                // Handle delete request
                                if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
                                    $id = intval($_GET['id']);
                                    mysqli_query($connect, "DELETE FROM `stock_out` WHERE `stockout_id`='$id'") or die(mysqli_error($connect));
                                    header("Location: stock_out_list.php");
                                    exit;
                                }

                                // Fetch stock-out details based on date range
                                if (isset($_GET['from_date']) && isset($_GET['to_date'])) {
                                    $from_date = $_GET['from_date'];
                                    $to_date = $_GET['to_date'];

                                    $current_date = strtotime($from_date);
                                    $end_date = strtotime($to_date);
                                    $sno = 1; // Initialize serial number

                                    while ($current_date <= $end_date) {
                                        $formatted_date = date("Y-m-d", $current_date);

                                        // Fetch data for the current date
                                        $stock_out_query = "SELECT `stockout_id`, `product_name`, `product_quantity`, `product_description`, `stockout_date` FROM `stock_out` WHERE `stockout_date` = '$formatted_date' ORDER BY `stockout_date` DESC";
                                        $result = mysqli_query($connect, $stock_out_query) or die(mysqli_error($connect));

                                        if (mysqli_num_rows($result) > 0) {
                                            echo "<div class='date-header'>DATE : " . date("d-m-Y", $current_date) . "</div>";
                                            
                                            echo "<div class='card'>
                                                <div class='card-body'>
                                                    <table class='table table-bordered table-striped'>
                                                        <thead>
                                                            <tr>
                                                                <th>S.No</th>
                                                                <th>Date</th>
                                                                <th>Product Name</th>
                                                                <th>Product Quantity</th>
                                                                <th>Description</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>";

                                            while ($row = mysqli_fetch_assoc($result)) {
                                                echo "<tr>
                                                        <td>" . $sno++ . "</td>
                                                        <td>" . htmlspecialchars($row['stockout_date']) . "</td>
                                                        <td>" . htmlspecialchars($row['product_name']) . "</td>
                                                        <td>" . htmlspecialchars($row['product_quantity']) . "</td>
                                                        <td>" . htmlspecialchars($row['product_description']) . "</td>
                                                    </tr>";
                                            }
                                            echo "</tbody>
                                                </table>
                                            </div>
                                        </div>";
                                        }

                                        // Move to the next day
                                        $current_date = strtotime("+1 day", $current_date);
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
